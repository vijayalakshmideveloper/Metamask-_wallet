import React from "react";
import Sidebar from "./common/Sidebar";
import './common/sidebar.css';

const DashBoard = () => {
  return (
    <div>
      <Sidebar />
    </div>
  );
};

export default DashBoard;