import React from "react";
import DashboardHome from "../../components/Dashboard/DashboardHome";

const DashboardHomePage = () => {
  return (
    <>
      <DashboardHome />
    </>
  );
};

export default DashboardHomePage;
