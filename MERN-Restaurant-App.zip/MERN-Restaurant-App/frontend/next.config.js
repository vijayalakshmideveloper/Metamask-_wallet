module.exports = {
  images: {
    domains: ["www.freepnglogos.com"],
  },
};
