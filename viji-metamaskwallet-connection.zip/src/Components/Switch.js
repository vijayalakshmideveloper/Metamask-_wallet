
import React, { useEffect, useState } from 'react';
import { DropdownButton, Dropdown, Button } from 'react-bootstrap';
import { ethers } from "ethers";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const networks = {
    ethereum: {
        chainId: `0x1`,
        chainName: "Ethereum Mainnet",
        nativeCurrency: {
            name: "ETH",
            symbol: "ETH",
        },
        rpcUrls: ["https://mainnet.infura.io/v3/"],
        blockExplorerUrls: ["https://etherscan.io"]
    },
    // polygon: {
    //     chainId: `0x89`,
    //     chainName: "Polygon Mainnet",
    //     nativeCurrency: {
    //         name: "MATIC",
    //         symbol: "MATIC",
    //     },
    //     rpcUrls: ["https://polygon-rpc.com/"],
    //     blockExplorerUrls: ["https://polygonscan.com/"]
    // },
    bsc: {
        chainId: `0x61`,
        chainName: "BNB Smart Chain Testnet",
        nativeCurrency: {
            name: "tBNB",
            symbol: "tBNB",
        },
        rpcUrls: ["https://data-seed-prebsc-1-s3.binance.org:8545/"],
        blockExplorerUrls: ["https://testnet.bscscan.com/"]
    },
    goerli: {
        chainId: `0x5`,
        chainName: "Goerli test network",
        nativeCurrency: {
            name: "GoerliETH",
            symbol: "GoerliETH",
        },
        rpcUrls: ["https://goerli.infura.io/v3/"],
        blockExplorerUrls: ["https://goerli.etherscan.io"]
    },

    sepolia: {
        chainId: `0xaa36a7`,
        chainName: "Sepolia test network",
        nativeCurrency: {
            name: "SepoliaETH",
            symbol: "SepoliaETH",
        },
        rpcUrls: ["https://sepolia.infura.io/v3"],
        blockExplorerUrls: ["https://sepolia.etherscan.io"]
    }
}


const changeNetwork = async ({ chainId, setError, setSuccess }) => {
    try {
        await window.ethereum.request({
            method: 'wallet_switchEthereumChain',
            params: [{ chainId }]
        });
        // console.log('${networks[chainId].chainName}', networks.bsc.chainName);
        setSuccess(`Switched to ${networks[chainId].chainName}`);
        alert("success")
    } catch (error) {
        setError("Failed to switch network");
        // alert(" Test Network has already been added to Metamask")
    }
};

function Switch() {
    const [balance, setBalance] = useState("");
    const [address, setAddress] = useState("");
    const [error, setError] = useState();
    const [selectedNetworks, setSelectedNetworks] = useState(localStorage.getItem('selectedNetwork') || 'ethereum')
    const [currentchainid, setcurrentchainid] = useState();
    const [MainetChainId, setMainetChainId] = useState();
    // const testnetadded = () => toast("Test Network has already been added to Metamask");
    let eth = currentchainid == '1';
    let BNB = currentchainid == '97'
    let Goerli = currentchainid == '5';
    let sep = currentchainid == '11155111'
    //    BNb 97 g 5 s 11155111

    const handleSwitch = async (networkName) => {

        console.log(MainetChainId == networkName, 'networkName');
        setError(error);
        setSelectedNetworks(networkName);
        // connectWallet()
        if (eth == networkName) {
            console.log(eth);
            toast(`ethereum mainnet to change Testnet ${networkName}`);
        }
        if (BNB) {
            console.log(eth);
            toast(`BNB mainnet to change Testnet ${networkName}`);
        }
        if (Goerli) {
            console.log(eth);
            toast(`Goerli Testnet to change Mainnet ${networkName}`);
        }
        if (sep) {
            // console.log(eth);
            toast(`sep Testnet to change mainnet${networkName}`);
        }

        // testnetadded();
        localStorage.setItem("Selected Networks", networkName)
        await changeNetwork({ chainId: networks[networkName].chainId, setError });


        if (setSelectedNetworks) {
            setError("Invalid network");
            return;
        }


        // Check if the network is already added to Metamask
        // if (window.ethereum && window.ethereum.chainId === setSelectedNetworks.chainId) {

        //     return;
        // }


    }

    const handleBalance = async () => {
        const provider = new ethers.BrowserProvider(window.ethereum);

        try {

            //Address
            const address = await provider.send("eth_requestAccounts", []);
            const currentAddress = address[0]
            setAddress(currentAddress);

            //Balance
            const balance = await provider.getBalance(currentAddress);
            setBalance(ethers.formatEther(balance));
            console.log("Balance:", balance);

        } catch (error) {
            console.error("Error:", error);
        }
    }

    useEffect(() => {
        const networkChanged = (chainId) => {
            console.log("chainID=====", chainId);
            setMainetChainId(chainId)
            Object.keys(networks).forEach(networkName => {
                if (networks[networkName].chainId === chainId) {

                    setSelectedNetworks(networkName);
                    localStorage.setItem("selectedNetwork", networkName);

                    setSelectedNetworks(networkName)
                    localStorage.setItem("Selected Networks", networkName)

                    
                }
                // connectWallet()
            })
        }
        window.ethereum.on("chainChanged", networkChanged)

        return () => {
            window.ethereum.removeListener("chainChanged", networkChanged)

        }

    }, [])



    async function getChainId() {
        try {
            const chainId = Number(await window.ethereum.request({ method: "eth_chainId" }));
            // const network = ethers.providers.getNetwork(chainId);
            console.log(`Network name: ${chainId}`);
            setcurrentchainid(chainId)
        } catch (error) {
            console.log(error);
        }
    }
    getChainId();

    const [isConnected, setIsConnected] = useState(false);

    const connectWallet = async (networkName) => {

        try {


            
            if (typeof window.ethereum !== 'undefined') {

                const binance = {
                    chainId: '0x38', 
                    chainName: 'Binance Smart Chain',
                    nativeCurrency: {
                        name: 'BNB',
                        symbol: 'BNB',
                        decimals: 18,
                    },
                    rpcUrls: ["https://bsc-dataseed.binance.org/"],
                    blockExplorerUrls: ["https://bscscan.com"]
                };
    
                await window.ethereum.request({
                    method: 'wallet_addEthereumChain',
                    params: [binance],
                });
    
                const networkId = await window.ethereum.request({
                    method: 'eth_chainId',
                });
    
                if (networkId === '0x38') { 
                    console.log('Switched to Binance Smart Chain');
                } else {
                    console.error('Failed to switch to Binance Smart Chain');
                }
                if(eth) {
                    toast(`Ethereum change to ${networkName}`);
                }
                if (BNB) {
                    toast(`BNB change to ${networkName}`);
                }
                if (Goerli) {
                    toast(`Goerli change to ${networkName}`);
                }
                if (sep) {
                    toast(`Sepolia change to ${networkName}`);
                }
                
            } else {
                console.error('MetaMask not installed.');
            }
        } catch (error) {
            console.error(error);
        }
    };


    return (
        <center>
            <ToastContainer />

            <DropdownButton id="dropdown-basic-button" title={`${networks[selectedNetworks].chainName}`}>
                <Dropdown.Item onClick={() => handleSwitch("ethereum")}>Ethereum</Dropdown.Item><br />
                {/* <Dropdown.Item onClick={() => handleSwitch("polygon")}>Polygon</Dropdown.Item><br/> */}
                <Dropdown.Item onClick={() => handleSwitch("bsc")}>BSC</Dropdown.Item><br />
                <Dropdown.Item onClick={() => handleSwitch("goerli")}>Goerli</Dropdown.Item><br />
                <Dropdown.Item onClick={() => handleSwitch("sepolia")}>Sepolia</Dropdown.Item><br />
            </DropdownButton>

            <div><br /><br /><br />
                <Button onClick={handleBalance} className='text-center' variant="success" >
                    Address: {address}
                    <br /> Wallet Balance: {balance}
                </Button>
            </div>

            <div className="App" >
                <h1>Balance Smart Chain Mainnet Wallet Connection</h1>
                {/* {isConnected  ? (  */}
                    <Button  onClick={()=>connectWallet("binance")}>Connected to Binance Smart Chain.</Button>
                {/* ) : (
                    <Button >Connect Wallet</Button>
                 )}  */}
            </div>

        </center>


    );
}

export default Switch;







  