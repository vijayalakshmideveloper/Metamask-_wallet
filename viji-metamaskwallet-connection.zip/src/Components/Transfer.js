import React, { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import { ethers } from 'ethers';
import abi from "./abi.json"
// import { Provider } from 'react';
function Transfer() {
  const [txs, setTxs] = useState([]);

  const myfunction = async ({ ether, addr }) => {
    const contractAddress = "0xeEaB5a8577e8AC82d6F162C4B17a85Fc362eB4E3";
   
    try {
      const provider = new ethers.BrowserProvider(window.ethereum);
      const addresses = await window.ethereum.request({ method: 'eth_requestAccounts' }, []);
      const address = addresses[0];
      console.log(address);

      const balance = await provider.getBalance(address);
      const balanceInEth = ethers.formatEther(balance);
      console.log('Balance in ETH:', balanceInEth);

      const signer = await provider.getSigner();
      const getAddress = await signer.getAddress();
      console.log("getAddress", getAddress);

      const contract = new ethers.Contract(contractAddress, abi, signer);
      const etherValue = ethers.parseUnits(ether.toString(), "ether");
      console.log("Ether Value:", etherValue);

      const newTxs = await contract.transfer(addr, etherValue);
      await newTxs.wait();
      setTxs([...txs, newTxs]);
      console.log("txcount", newTxs);
      alert("success")

    } catch (error) {
      console.error('Error:', error);
      alert("failed")
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const data = new FormData(e.target);
    await myfunction({
      ether: data.get("ether"),
      addr: data.get("addr")
    });
  };


  return (
    <div>
      <h1 className='d-flex'> Transfer </h1>
      <Form onSubmit={handleSubmit}>
        <Form.Group className="mb-3 d-flex">
          <Form.Label>Address:</Form.Label>
          <Form.Control type="text" name="addr" placeholder="Network Address" />
        </Form.Group>

        <Form.Group className="mb-3 d-flex">
          <Form.Label>Amount:</Form.Label>
          <Form.Control type="text" name="ether" placeholder="ETH Amount" />
        </Form.Group>
        <Button variant="primary" type="submit">
          Submit
        </Button>
      </Form>
      {txs.map((tx, index) => (
        <p key={index}>{tx.address}</p>
      ))}
    </div>
  );
}



// async function getBalance(address) {
//   try {
//     const balanceWei = await provider.getBalance(address); // Use ethers.provider.getBalance
//     const balanceEth = ethers.formatEther(balanceWei); // Use ethers.utils.formatEther
//     return balanceEth;
//   } catch (error) {
//     console.error("Error fetching balance:", error);
//     return null;
//   }
// }

// Replace with the Ethereum address you want to check
// const addressToCheck = '0x877c3014eAEBfC847e795a34B7a5e592401f98dC';

// getBalance(addressToCheck)
//   .then(balance => {
//     if (balance !== null) {
//       console.log(`Account balance of ${addressToCheck}: ${balance} ETH`);
//     } else {
//       console.log(`Failed to retrieve balance for ${addressToCheck}`);
//     }
//   });




export default Transfer;