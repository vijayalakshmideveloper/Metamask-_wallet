import React, { useState } from 'react';
import { ethers } from 'ethers';
import abi from "./abi.json";


const TokenInfoDisplay = () => {

  const tokenContractAddress = '0xeEaB5a8577e8AC82d6F162C4B17a85Fc362eB4E3';

  const [token, setToken] = useState({
    name: "",
    symbol: "",
    totalSupply: "",
    address: "",
    balanceOf:""
  })

  async function sumbit() {
    const provider = new ethers.BrowserProvider(window.ethereum)
    const address = await provider.send("eth_requestAccounts", []);
    console.log("address", address);

    const contract = new ethers.Contract(tokenContractAddress, abi, provider)
    const balance = await contract.balanceOf(address[0])
    console.log("balance", balance);

    const Name = await contract.name()
    // const balanceOf =await contract.balanceOf()
    console.log("Name", Name);
    const Symbol = await contract.symbol()
    const TotalSupply = await contract.totalSupply()
    
    setToken({
      address: address[0],
      name: Name,
      symbol: Symbol,
      totalSupply: ethers.formatUnits(TotalSupply.toString(),24),
      balanceOf: ethers.formatUnits (balance.toString(),18),
      
    })

  }

  return (
    <div>
      <h4> {"Get/Set Contract interaction"} </h4>
      <button
        onClick={sumbit}
      >Wallet      </button>

      <h3>Address: {token.address}</h3>

      <h3>name: {token.name}</h3>
      <h3>symbol: {token.symbol}</h3>
      <h3>totalsupply: {token.totalSupply}</h3>
      <h3>balanceOf: {token.balanceOf}</h3> 
      
       
    </div>
  );
};

export default TokenInfoDisplay;
