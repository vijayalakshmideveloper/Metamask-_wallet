// import React, { useState, useEffect } from 'react';
// import './App.css';

// import Web3 from 'web3';
import SimpleStorage from './Components/SimpleStorage';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import TokenInfoDisplay from './Components/TokenInfoDisplay';
import Transfer from './Components/Transfer';
import Switch from './Components/Switch';
function App() {
  return (
    <div className="App">
        <BrowserRouter>
            <Routes>
                <Route  path='/' Component={SimpleStorage} />
                <Route  path='/token' Component={TokenInfoDisplay} />
                <Route  path='/transfer' Component={Transfer} />
                <Route  path='/Switch' Component={Switch} />
            </Routes>
        </BrowserRouter>
    </div>
  );
}

export default App;
