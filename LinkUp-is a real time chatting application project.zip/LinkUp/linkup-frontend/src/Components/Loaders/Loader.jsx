import './loader.css';
const Loader = () => {
   
  return (
    <div className="loader">
        <div className="load-roller"></div>
    </div>
  )
}

export default Loader   ;