exports.CLIENT_ORIGIN = process.env.NODE_ENV === 'production'
  ? 'https://whispering-bastion-31600.herokuapp.com'
  : 'http://localhost:3000'