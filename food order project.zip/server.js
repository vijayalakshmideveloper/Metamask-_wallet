const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const session = require('express-session');
const Mongostore = require('connect-mongo');
const ejs = require("ejs")
const path = require("path")
const router = require("./routers/router");
const productRouter = require("./routers/productrouter")

const app = express();
app.use (express.json())

app.use (bodyParser.json())
app.set("view engine","ejs")
// app.set("view",(path.join(__dirname,"public")))

// app.set(express.static(path.join(__dirname,"public")))
app.use(express.static(__dirname +'public'))
app.use(express.static("public"))
app.use(bodyParser.urlencoded({extended:false}));

mongoose.connect("mongodb+srv://smnithish2000:niki2000@cluster0.90l5qsx.mongodb.net/food",
{useNewUrlParser:true, useUnifiedTopology:true},
console.log("conntect"))
app.use(session({
    secret: 'signIn',
    resave: false,
    saveUninitialized: true,
    store: Mongostore.create({ mongoUrl: 'mongodb+srv://smnithish2000:niki2000@cluster0.90l5qsx.mongodb.net/food' })
}));


app.use("/",router);
app.use('/',productRouter);
app.listen(4000,()=>{
console.log("4000")
})
