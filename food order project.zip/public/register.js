$(function(){
    var $registerForm = $("#registration");
    $.validator.addMethod("noSpace",function(value,element){
      return value == '' || value.trim().length !=0
    },"spaces are not allowed");
  
    console.log("$registerForm",$registerForm);
    if($registerForm.length){
        $registerForm.validate({
            rules:{
                name:{
                    required:true,
                    noSpace:true
                  },
                email:{
                    required:true,
                    email:true
                  },
                password:{
                    required:true
                  },
                  repeat:{
                    required:true,
                    equalTo:'#password'
                  },
                 
            },
            messages:{
                name:{
                    required:"please enter username"
                },
                email:{
                    required:"please enter email",
                    email:"please enter valid email"
                },
                password:{
                  required:"please enter password"
                },
                repeat:{
                  required:"please enter confirm password",
                  equalTo:"please enter the same password"
                },
        
              
              }
        })
    }
  })