const mongoose = require("mongoose");
const schema = mongoose.Schema
const store = new schema({
    name:{
        type:String,
        require: true

    },
    email:{
        type:String,
        require:true
    },
    password:{
        type:String,
        require: true

    },
    repeat:{
        type:String,
        require: true

    },
   
   
})

module.exports=mongoose.model("order",store)
