const mongoose = require("mongoose");
const schema = mongoose.Schema
const product = new schema({
    foodname:{
        type:String,
        require: true

    },
    RS:{
        type:Number,
        require:true
    },
    stock:{
        type:String,
        require:true

    },
    imageUrl:{
        type: String
    }
   
   
})

module.exports=mongoose.model("productlist",product)