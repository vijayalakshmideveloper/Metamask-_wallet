const authLogin = ( req, res, next ) =>{
    try {
        if(req.session.user){ }
        else{
            res.redirect("/sign-in")
        }
        next();
    } catch (error) {
        console.log("AuthLogin---error");
    }
}


const authLogout = ( req, res, next) =>{
    try {
        if(req.session.user){
            res.redirect("/food")
        }
        next();
    } catch (error) {
        console.log("AuthLogout---error");
    }
}

module.exports = { authLogin, authLogout }