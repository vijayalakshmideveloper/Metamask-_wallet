const express = require("express");
const router = express.Router();
router.use (express.json());
const controller = require("../controller/userController");
const auth = require("../session/auth")


//home
router.get("/food",auth.authLogin, controller.food)

// menu
router.get("/menu",auth.authLogin,controller.menu)

// login
router.get('/Register',auth.authLogout, controller.regi)
router.post("/register", controller.register)

// show
// router.get("/show",auth.authLogin, controller.show)

// usersign-in
router.get("/sign-in",auth.authLogout, controller.sign)
router.post("/sign-in", controller.login)

//Logout
router.get("/logout", auth.authLogin, controller.logout)


// admin 
router.get("/admin",auth.authLogin, controller.admin)

// shop 
// router .get("/cart",auth.authLogin, controller.shop)



















module.exports =router;