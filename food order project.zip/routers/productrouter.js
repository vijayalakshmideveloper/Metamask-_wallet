const express = require("express");
const router = express.Router();
router.use (express.json());
const product  =require("../controller/productController")


//product 
router.get("/order",product.order);
//create 
router.post("/addfood",product.addfoods)

router.get("/cart",product.foodlist)






module.exports =router;