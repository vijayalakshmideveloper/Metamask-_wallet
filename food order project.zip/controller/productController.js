const details = require("../modules/product")

const order = async (req, res) => {
   res.send("worked")
}

const addfoods = async (req, res) => {
   const user = new details({
      foodname: req.body.foodname,
      RS: req.body.RS,
      stock: req.body.stock

   })
   const value = await user.save()
   res.send(value)

}


//  find product 



const foodlist =('/list', async (req, res) => {
   try {
     const food = await details.find();
   console.log(food);
     res.render("cart", { data: food });
    
   } catch (error) {
     // Handle any errors that occur during the execution
     console.error(error);
     res.status(500).send("Internal Server Error");
   }
 });
 

module.exports = { order, addfoods, foodlist }