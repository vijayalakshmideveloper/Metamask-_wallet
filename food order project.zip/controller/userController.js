const result =require("../modules/module");
const CryptoJS = require("crypto-js")
const path = require('path')
//home
const food = async(req,res)=>{
    res.render("index")
  }
  //menu
  const menu = async(req,res)=>{
    res.render("menu")
  }
//register
const regi = (req,res) =>{
    res.render("Register")
}

  const register = async(req,res)=>{
    var password = CryptoJS.AES.encrypt(req.body.password, 'nithish123').toString();

    const { name, email } = req.body;
    const data = new result({
        name,email,password
    })
    try {
        const value = await data.save()
        res.status(200).send({message: "Register Successfully...", value})
    } catch (error) {
        res.status(400).send({message: "Register Failed..."})
    }
   }
//user sign
   const sign=async(req,res)=>{
    res.render("sign-in")
  }

   // Login
   var login =  async (req, res) => {
 try {
   var user = await result.findOne({ email: req.body.email });
//    req.session.user=user

        if (!user) {
            res.status(400).send("User not found");
            return;
        }
        // console.log("user", user.password);


        let userDbPassword = user.password
        var bytes = CryptoJS.AES.decrypt(userDbPassword, 'nithish123');
        // console.log("bsuccessytes", bytes);
        var originalText = bytes.toString(CryptoJS.enc.Utf8);
        // console.log("originalText", originalText);

        if (originalText !== req.body.password) {
            res.status(400).send({status:false,message:"invalid password..!"});
            return;
        }
        else {
            req.session.user = user;
            // res.redirect('/success');
            res.status(200).send({status:true,message:"login successfully!"});
        }

    } catch (error) {
        res.status(400).send({status:false,message:"please signup first..!"});
        // res.status(400).send("")
    }
}

// //show
//    const show =async(req,res)=>{
//     const value = await result.find()
//     res.render("form",{list: value})
// }





//admin
const admin =async(req,res)=>{
    res.render("admin")
  }

//admin
// const shop =async(req,res)=>{
    
//   res.render("cart");
    
//   }

//logout
const logout = (req,res)=>{
    try {
        req.session.destroy()
        res.redirect("/sign-in");
    } catch (error) {
        res.send("error occured..")
    }
}



  module.exports = { food, register,regi ,sign,admin, login,menu, logout}