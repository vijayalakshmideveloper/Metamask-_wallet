const express = require('express')
const router = express.Router()
const multer = require('multer');
const studentController = require('../controllers/studentsController');
const auth = require("../authentication/auth")


// Configure multer storage
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, 'uploads/'); // Directory where images will be stored
    },
    filename: (req, file, cb) => {
      cb(null, Date.now() + '-' + file.originalname); // Add a timestamp to the filename to avoid overwriting
    },
  });
  
  const upload = multer({ storage: storage });

// middleware session
const checkSession = (req, res, next) => {
  try {
      console.log(req.session, "req.session.user");
      if (req.session.user) {
          next();
      } else {
          res.status(401).send('Session not created'); // Sending 401 Unauthorized status for unauthenticated requests
      }
  } catch (error) {
      console.log("AutoLogin----error", error);
      res.status(500).send('Server Error'); // Sending 500 Internal Server Error for unexpected errors
  }
};

router.get('/',studentController.get)

router.post('/create',studentController.post)

router.get('/getstudents/:id',studentController.update)

router.put('/updatestudents/:id',studentController.put)

router.delete('/deletestudents/:id',studentController.remove)




router.post('/login', studentController.login,checkSession);
router.post('/reg',studentController.register)
router.post('/mail',studentController.Mail)
// router.post("/email,studentController.Email")
module.exports= router