const express = require('express')
const mongoose = require ('mongoose')
const cors = require('cors')
const router = require('./router/router')
const session = require('express-session')
const Mongo = require ('connect-mongo')
const app = express()
// const socketIo = require('socket.io');
const http = require('http');

//socket
// const part = require("part");
// const { Server } = require("socket.io");
// const { fileURLToPath } = require("url");
// const route = require("./api/routes.js");
// const sockets = require("./socket/sockets.js");
// // import { fileURLToPath } from 'url';
// // import path from 'path'; // Import the 'path' module




app.use(express.json())
app.use(cors())





mongoose.connect('mongodb+srv://vijimurugan797:viji12345@viji.qdvlzw0.mongodb.net/dept')
.then(() => {
    console.log("DB connected")
})
.catch((err) =>{
    console.log ("DB not connected")
})
//session
app.use(session({
  
    secret: "loginForm",
    resave: false,
    saveUninitialized: false,
    store: Mongo.create({ mongoUrl:'mongodb+srv://vijimurugan797:viji12345@viji.qdvlzw0.mongodb.net/dept'})
  }))

// app.get('/',(req,res)=>{
//     student.find({})
//     .then(users => res.json(users))
//     .catch(err => res.json)
// })

// app.post('/createstudents',(req,res)=>{
//     student.create(req.body)
//     .then(users => res.json(users))
//     .catch(err => res.json(err))
// })


//socket
// const httpServer = http.createServer(app);
// const io = new Server(httpServer, {
//   cors: {
//     origin: ["http://localhost:3005"],
//   },
// });



// const __filename = fileURLToPath(import.meta.url);
// const __dirname = path.dirname(__filename);

// app.use(cors());
// app.get("/", (req, res) => {
//   res.sendFile(__dirname + "/index.html");
// });
// app.use("/", router);

// io.on("connection", sockets);














app.use('/',router)

app.listen('3005',() => {
    console.log ("server is running")
})