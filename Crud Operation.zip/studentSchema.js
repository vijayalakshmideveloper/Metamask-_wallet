const mongoose = require('mongoose')
const Schema = new mongoose.Schema({
   name:{
       type:String 
   },
   roll:{
       type:String
   },
   tamil:{
      type:String
   },
   english:{
    type:String
   },
   maths:{
     type: String
   },
   science:{
     type: String
   },  
   social:{
    type: String
   }
})

module.exports = mongoose.model('student',Schema)