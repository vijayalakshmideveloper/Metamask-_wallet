const authLogin = (req,res,next)=>{
    try{
        if(req.session) {
            res.redirect('http://localhost:3005/')
        }
        else{
         next();
        }
    }
    catch(err){
        console.log("authlogin error",err)
    }
};


const authLogout = (req,res,next)=>{
    try{
        if(!req.session){
            res.redirect('/login');
        }
        else{
            next();
        }
    }
    catch(err){
        console.log("authlogout error",err)
    }
}

module.exports = {authLogin,authLogout}