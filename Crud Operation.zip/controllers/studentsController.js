const { request } = require('http')
const student = require("../studentSchema")
const userschema = require('../userSchema')
const CryptoJS = require("crypto-js");
const jwt = require('jsonwebtoken');
const Token =require('../authSchema')
const mailer = require('nodemailer');
const get = (req, res) => {
    student.find()
        .then(users => res.json(users))
        .catch(err => res.json(err))
}

const post = (req, res) => {
    student.create(req.body)
        .then(users => res.json(users))
        .catch(err => res.json(err))// Get the image file path from multer
}

const update = (req, res) => {
    const id = req.params.id;
    student.findByIdAndUpdate({ _id: id }, req.body) // Update the document with the entire req.body
        .then(users => res.json(users))
                .catch(err => res.json(err))
}

const put = (req, res) => {
    const id = req.params.id; 
    const image = req.file ? req.file.path : null; // Get the image file path from multer

    student.findByIdAndUpdate({ _id: id },
    
        {
            name: req.body.name,
            roll: req.body.roll,
            tamil: req.body.tamil,
            english: req.body.english,
            maths: req.body.maths,
            science: req.body.science,
            social: req.body.social,
        })
        .then(users => res.json(users))
        .catch(err => res.json(err))
}

const remove = (req,res) =>{
    const id = req.params.id;
    student.findByIdAndDelete({_id:id})
    .then(res => res.json(res))
    .catch(err => console.log(err))
}

const register = async (req,res) =>{
    var password = CryptoJS.AES.encrypt(req.body.password, 'viji123').toString();

    const { username,email} = req.body;

   const user = new userschema({
       username,
       email,
       password
       

   });
   try {
       const value= user.save();
       res.send({ status: true, message: "user created successfully", value })
   } catch (err) {
       res.send({ status: false, message: "failed creation" })
   }

}


const login = async (req, res) => {
    try {
        const value = await userschema.findOne({ email:req.body.email });
        // console.log(value,"000000000");

        if (!value) {
            res.status(400).send({ status: false, message: "User not found" });
            return;
        }

        let userPassword = value.password;
        var bytes = CryptoJS.AES.decrypt(userPassword, 'viji123');
        var originalText = bytes.toString(CryptoJS.enc.Utf8);

        if (originalText !== req.body.password) {
            res.status(400).send({ status: false, message: "Invalid password..!" });
            return;
        }

        const token = jwt.sign({ userId: value._id }, 'viji123', {
            expiresIn: '1h'
        });

        res.cookie('jwt', token, {
            httpOnly: true,
        });

        const authdata = new Token({
            user_id: value._id,
            token: token,
            expiration: new Date(Date.now() + 3600000), // 1 hour
        });
              
        // req.session.user = value;
        // req.session.save();

        try {
            await authdata.save();
            res.status(200).send({ status: true, message: "Login successful!" });
        } catch (error) {
            res.status(500).send({ status: false, message: "Failed to save auth data." });
        }
    } catch (error) {
        res.status(400).send({ message: "Server Error. Please try again later." });
    }
};
  
// //  mail
// const MailSend = async(req,res)=>{
//     const email = req.body.email
//     const transporter = mailer.createTransport({
//     service: "gmail",
//     auth: {
//     user: 'vijimurugan797@gmail.com',
//     pass: ''
//     }
//     });
//     const mailerobject = ({
//     from: 'vijimurugan797@gmail.com',
//     to: email,
//     subject: "",
//     text: "hiiiii",
//     });
    
//     await transporter.sendMail(mailerobject, (error,info) => {
//     if (error) {
//     console.log("mail error");
//     } else {
//     console.log("result :",info.response);
//     res.send(mailerobject.text)
//     }
    
//     })
//     };



//mail

const Mail = async (req, res) => {
    const { email } = req.body;
    try {
        // Find the user based on the provided email
        const User = await userschema.findOne({ email });
        // if (!User) {
        //   return res.status(404).json({ status: false, message: "User not found" });
        // }

        // Generate a JWT token with a short expiration time (e.g., 15 minutes)
        const token = jwt.sign({ user_id: User._id }, 'viji123', { expiresIn: '15m' });

        const newToken = new Token({
            token: token,
            user_id: User._id,
            expiration: new Date(Date.now() + 900000),
            status: "forgottoken"
        });

        await newToken.save();
        // Send the password reset link to the user's email
        const transporter = mailer.createTransport({
            service: "Gmail",
            auth: {
                user: "vijimurugan797@gmail.com",
                pass: "bhwwofqxisnvceuh",
            },
        });

        const Link = `http://localhost:3000/resetpassword/${email}/${token}`;

        const mailSelect = {
            from: "vijimurugan797@gmail.com",
            to: email,
            subject: "Password Reset",
            html: `<p>Click <a href="${Link}">here</a> to reset your password.</p>`
        };

        transporter.sendMail(mailSelect, (error, info) => {
            if (error) {
                console.error("Error sending email:", error);
            } else {
                console.log("Password reset link sent:", info.response);
            }
        });
        res.json({ status: true, message: "Reset token generated and email sent successfully" });
    } catch (error) {
        res.status(500).json({ status: false, message: "Password reset failed", error });
    }
};


// //socket


// const.message('/send', (req, res) => {
//     const { message } = req.body; // Assuming you're sending the message in the request body
  
//     if (message) {
//       io.emit('message', message); // Broadcast the message to all connected clients
//       res.status(200).send('Message sent successfully');
//     } else {
//       res.status(400).send('Message cannot be empty');
//     }
//   });

  module .exports ={get,post,update,put,remove, register, login,Mail,}


