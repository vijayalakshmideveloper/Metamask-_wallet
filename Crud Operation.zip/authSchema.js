const mongoose = require('mongoose');
const Token = mongoose.Schema({
    user_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "userDetails"
    },
    token: {
        type:String
    },
    expiration:{
        type:Date
    },
    status: {
        type:String,
        default:"Active"
    },
});
Token.index({ expiration: 1 }, { expireAfterSeconds: 0 });

module.exports = mongoose.model("token", Token);