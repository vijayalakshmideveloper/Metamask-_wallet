import React from 'react';
import Layout from './Layout';

const App = () => {
  return (
    <div className="App">
        <Layout />
    </div>
  );
}

export default App;
